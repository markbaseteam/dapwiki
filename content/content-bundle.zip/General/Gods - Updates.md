---
quickshare-date: 2023-11-25 20:14:16
quickshare-url: "https://noteshare.space/note/clpeo4lpm1984701mwazn0nws1#MKifmbdZyW/A2toxqL21F26iXg5wzpCv1EKzOCxFGp0"
---
Parent::[[Planning Workspace/Shyi/Roadmap|Roadmap]]
Friend::[[Magical Systems]]
# Tasks
- [ ] Descriptions
	- [ ] [[#Gods' Descriptions|Gods]]
		- [x] [[#[Ŝtrigo](https //www.youtube.com/watch?v=xmckBT-IUeE&t=67) - Royal’s Limit|Ŝtrigo]]
		- [ ] [[#Rikan - Child’s Play|Rikan]]
		- [ ] [[#Amikino - Man's Best Friend|Amikino]]
		- [ ] [[#[Ŝanĝilo](https //www.youtube.com/watch?v=4ulbaSwsfKU&t=54) - Thief’s Afterlife|Ŝanĝilo]]
		- [ ] [[#[Ĉaristo](https //www.youtube.com/watch?v=44LambNZgd4&t=136) - Thespian’s Sun|Ĉaristo]]
		- [x] [[#Alko - Animal’s Nature|Alko]]
		- [ ] [[#Kura - Medic’s Drink|Kura]]
		- [ ] [[#Iona - Mother’s Love|Iona]]
		- [ ] [[#Miso - Diplomat’s Pacifism|Miso]]
		- [ ] [[#Tikva - Fairy’s Tale|Tikva]]
		- [ ] [[#Daite - Whore’s Pleasure|Daite]]
		- [ ] [[#Ĉasis - Hunter’s Purity|Ĉasis]]
		- [ ] [[#Ondo - Farer’s Waters|Ondo]]
		- [ ] [[#Fares - Worker’s Forger|Fares]]
		- [ ] [[#Baroj - Farmer’s Dream|Baroj]]
		- [ ] [[#Floraj - Season’s Place|Floraj]]
		- [ ] [[#Moze - Zealot’s Sacrifice|Moze]]
		- [ ] [[#[Ilaro](https //www.youtube.com/watch?v=goA3TXoAfrI) - Champion’s Goal|Ilaro]]
		- [ ] [[#Titak - Mortal’s Time|Titak]]
		- [ ] [[#Buro - Warrior’s Purpose|Buro]]
		- [ ] [[#Histera - Drunkard's Pleasure|Histera]]
	- [ ] [[#Author's Descriptions|Authors]]
		- [ ] [[#[Kaŭri](https //www.youtube.com/watch?v=GRdj8MRj9Js&t=150) - Impossible Author|Kaŭri]]
		- [ ] [[#Teksi - Form of Life Author|Teksi]]
		- [ ] [[#Kaŝi - Magic Author|Kaŝi]]
		- [ ] [[#Disiĝi - Land Author|Disiĝi]]
		- [ ] [[#Antaŭdi - History Author|Antaŭdi]]
	- [ ] Images
		- [ ] [[#God’s Descriptions |Gods]]
			- [ ] [[#Appearance - ŝtrigo|Ŝtrigo]]
			- [ ] [[#Appearance - Rikan|Rikan]]
			- [ ] [[#Appearance - Amikino|Amikino]]
			- [ ] [[#Appearance - Ŝanĝilo|Ŝanĝilo]]
			- [ ] [[#Appearance - Ĉaristo|Ĉaristo]]
			- [ ] [[#Appearance - Alko|Alko]]
			- [ ] [[#Appearance - Kura|Kura]]
			- [ ] [[#Appearance - Iona|Iona]]
			- [ ] [[#Appearance - Miso|Miso]]
			- [ ] [[#Appearance - Tikva|Tikva]]
			- [ ] [[#Appearance - Daite|Daite]]
			- [ ] [[#Appearance - Ĉasis|Ĉasis]]
			- [ ] [[#Appearance - Ondo|Ondo]]
			- [ ] [[#Appearance - Fares|Fares]]
			- [ ] [[#Appearance - Baroj|Baroj]]
			- [ ] [[#Appearance - Floraj|Floraj]]
			- [ ] [[#Appearance - Moze|Moze]]
			- [ ] [[#Appearance - Ilaro|Ilaro]]
			- [ ] [[#Appearance - Titak|Titak]]
			- [ ] [[#Appearance - Buro|Buro]]
			- [ ] [[#Appearance - Histera|Histera]]
		- [ ] Authors
			- [ ] [[#Appearance - Kaŭri|Kaŭri]]
			- [ ] [[#Appearance - Teksi|Teksi]]
			- [ ] [[#Appearance - Kaŝi|Kaŝi]]
			- [ ] [[#Appearance - Disiĝi|Disiĝi]]
			- [ ] [[#Appearance - Antaŭdi|Antaŭdi]]
	- [ ] Symbols
		- [ ] [[#Godly Sigils |Gods]]
			- [x] [[#Sigil - Ŝtrigo|Ŝtrigo]]
			- [x] [[#Sigil - Rikan|Rikan]]
			- [ ] [[#Sigil - Amikino|Amikino]]
			- [x] [[#Sigil - Ŝanĝilo|Ŝanĝilo]]
			- [x] [[#Sigil - Ĉaristo|Ĉaristo]]
			- [x] [[#Sigil - Alko|Alko]]
			- [x] [[#Sigil - Kura|Kura]]
			- [x] [[#Sigil - Iona|Iona]]
			- [x] [[#Sigil - Miso|Miso]]
			- [x] [[#Sigil - Tikva|Tikva]]
			- [x] [[#Sigil - Daite|Daite]]
			- [x] [[#Sigil - Ĉasis|Ĉasis]]
			- [x] [[#Sigil - Ondo|Ondo]]
			- [x] [[#Sigil - Fares|Fares]]
			- [x] [[#Sigil - Baroj|Baroj]]
			- [x] [[#Sigil - Floraj|Floraj]]
			- [x] [[#Sigil - Moze|Moze]]
			- [x] [[#Sigil - Ilaro|Ilaro]]
			- [x] [[#Sigil - Titak|Titak]]
			- [x] [[#Sigil - Buro|Buro]]
			- [ ] [[#Sigil - Histera|Histera]]
		- [ ] [[#Authors' Sigils |Authors]]
			- [x] [[#Sigil - Kaŭri|Kaŭri]]
			- [ ] [[#Sigil - Teksi|Teksi]]
			- [ ] [[#Sigil - Kaŝi|Kaŝi]]
			- [ ] [[#Sigil - Disiĝi|Disiĝi]]
			- [ ] [[#Sigil - Antaŭdi|Antaŭdi]]
- [x] Name Updates

# Names
[[Character Workspace/Shyi/Characters/Gods|Gods]]
[[Authors]]

All of them were passed to a naming scheme resembling Esperanto.
# Descriptions

## Author's Descriptions
Above all other creatures and gods alike, the five authors are responsible for the creation of the universe and the rules which the gods must abide by. They're unreachable and mysterious. They lack bodies and can only speak by possessing mortals, using them as "bridges" between them and us.
### [Kaŭri](https://www.youtube.com/watch?v=GRdj8MRj9Js&t=150) - Impossible Author
<!--
Goddess of wisdom. An ancient being who walks the land, giving people advice in exchange for gifts, such as tobacco or blood. The goddess often takes the form of a mummified woman with long, tendril-like hair and no face to speak of; only void where a face should be. Although a terrifying and ominous presence, Kaŭri is described as oddly kind-hearted and with inclinations towards beautiful women.
-->
**Update description.**
#### Appearance - Kaŭri
#### Aspects
#### Sigil - Kaŭri
![[Kaŭri_Sigil.jpg]]
### Teksi - Form of Life Author
The one who weaves life into the world, creator of all living beings on the planet. Kind-hearted but lonesome.
#### Appearance - Teksi
#### Aspects
#### Sigil - Teksi
### Kaŝi - Magic Author
The one who bleeds magic into the world, creator of all sorcery. Aloof and very distant, often described as shy.
#### Appearance - Kaŝi
#### Aspects
#### Sigil - Kaŝi
### Disiĝi - Land Author
The one who terraforms, creator of mountains, forests, chasms and everything on land and sea. Jolly, but a bit of a bully.
#### Appearance - Disiĝi
#### Aspects
#### Sigil - Disiĝi
### Antaŭdi - History Author
The one who writes the stories of each living being, from start to finish, decider of fate. Blunt and often cold, but wise.
#### Appearance - Antaŭdi
#### Aspects
#### Sigil - Antaŭdi

## Gods' Descriptions
They're all-powerful in their respective aspects and they like to be worshipped. Although mortal by technicality, they have very lengthy lifespans.
### [Ŝtrigo](https://www.youtube.com/watch?v=xmckBT-IUeE&t=67) - Royal’s Limit
God of winter, snow and hail.
Ŝtrigo (Meaning: Owl) /Shtrigo/
#### Appearance - ŝtrigo
**Material**: Scales and Feathers.
As the creator of birds El is the spitting image of them, god of the sky and weather he created animals in his image, animals that soar and glide and jump to great heights despite being small.
He is one of the shortest gods, being measure only at 3-4m tall, he’s soft and looks like a giant barn owl with a humanoid face.
#### Personality
Arrogant, judgmental, But caring and sweet when he wants to be. His demeanor is normally as such thanks to his melancholic and royal status, however when left with people who show him care and love he becomes sweet and kind to them and those around them.
#### Aspects
Skies, Melancholy, Weather.
#### Sigil - Ŝtrigo
![[Ŝtrigo_Sigil.jpg]]
### Rikkan - Child’s Play
Rikan (Meaning: Mayhem)

#### Description/Backstory
Rikkan was created by Kauri to cause more interesting things to happen in Antaudi's stories.
He's chaos and childish imagination.
He has 3 champions, Fatou (Violence), Kat (Sadism), Lotus (Madness).
#### Appearance - Rikkan
A creepy wooden doll that looks like a clown.
![[Rikkan_1.jpg]]
![[Rikka_2.jpg]]
#### Sigil - Rikan
![[Rikan_Sigil.jpg]]
### Kura - Medic’s Drink
#### Appearance - Kura
#### Aspects
Medicine, Potions, Poisons, Beer, Disability, Mental Health, Illness.
#### Sigil - Kura
![[Kura_Sigil.jpg]]
### Iona - Mother’s Love
#### Appearance - Iona
#### Aspects
Family, Motherhood, Birth, Marriage.
#### Sigil - Iona
![[Iona_Sigil.jpg]]
### Miso - Diplomat’s Pacifism
#### Appearance - Miso
#### Aspects
Peace, Diplomacy, International Relations, Interpersonal Understanding.
#### Sigil - Miso
![[Miso_Sigil.jpg]]
### Tikva - Fairy’s Tale
#### Appearance - Tikva
#### Aspects
Nightmares, Fairies, Puzzles, Traps.
#### Sigil - Tikva
![[Tikva_Sigil.jpg]]
### Daite - Whore’s Pleasure
#### Appearance - Daite
#### Aspects
Love, Jealousy, Beauty, Prostitution, Gender.
#### Sigil - Daite
![[Daite_Sigil.jpg]]
### Ĉasis - Hunter’s Purity
#### Appearance - Ĉasis
#### Aspects
Hunting, Virginity, Protection, Womanhood.
#### Sigil - Ĉasis
![[Ĉasis_Sigil.jpg]]
### Ondo - Farer’s Waters
#### Appearance - Ondo
#### Aspects
Sea, Lakes, Water, Merfolk, Water Faring.
#### Sigil - Ondo
![[Ondo_Sigil.jpg]]
### Fares - Worker’s Forger
#### Appearance - Fares
#### Aspects
Blacksmithing, Work, Honesty, Law, Balance.
#### Sigil - Fares
![[Fares_Sigil.jpg]]
### Baroj - Farmer’s Dream
#### Appearance - Baroj
#### Aspects
Agriculture, Bees, Harvest.
#### Sigil - Baroj
![[Baroj_Sigil.jpg]]
### Floraj - Season’s Place
#### Appearance - Floraj
[Inspiration](https://antifandom.com/disney/wiki/Spring_Sprite)
#### Aspects
Seasons, Biomes, Famine, Abundance.
#### Sigil - Floraj
![[Floraj_Sigil.jpg]]
### Moze - Zealot’s Sacrifice
#### Appearance - Moze
#### Aspects
Sacrifice, Rituals, Riches, Fires, Volcanoes.
#### Sigil - Moze
![[Moze_Sigil.jpg]]
### [Ilaro](https://www.youtube.com/watch?v=goA3TXoAfrI) - Champion’s Goal
#### Description/Backstory
Sister of Rikkan, made by Kauri, to balance out the chaos he brought.
#### Appearance - Ilaro
#### Aspects
Fun, Toys, Loyalty, Friendship.
#### Sigil - Ilaro
![[Ilaro_Sigil.jpg]]
### Titak - Mortal’s Time
#### Description/Backstory
Created by Antaudi to have a companion who saw the possibilities and funs of stories like she did.
#### Appearance - Titak
#### Aspects
Time, Change, Immortality, Eternity, Music.
#### Sigil - Titak
![[Titak_Sigil.jpg]]
### [Ĉaristo](https://www.youtube.com/watch?v=44LambNZgd4&t=136) - Thespian’s Sun
Ĉaristo (Meaning: Charioteer) /Charisto/
#### Appearance - Ĉaristo
#### Aspects
Sun, Life, Growth, Satisfaction.
#### Sigil - Ĉaristo
![[Ĉaristo_Sigil.jpg]]
### [Ŝanĝilo](https://www.youtube.com/watch?v=4ulbaSwsfKU&t=54) - Thief’s Afterlife
Ŝanĝilo (Meaning: One who Changes) /Shandjilo/
#### Appearance - Ŝanĝilo
#### Aspects
Moon, Death, Afterlife Journey, Eclipse.
#### Sigil - Ŝanĝilo
![[Ŝanĝilo_Sigil.jpg]]
### Alko - Animal’s Nature
Alko (Meaning: Elk)
#### Appearance - Alko
#### Aspects
Nature, Vengeance, Isolation, Trust.
#### Sigil - Alko
![[Alko_Sigil.jpg]]
### Buro - Warrior’s Purpose
#### Appearance - Buro
#### Aspects
War, Battle, Intrapersonal Desire.
#### Sigil - Buro
![[Buro_Sigil.jpg]]
### Amikino - Man's Best Friend
Amikino (Meaning: Friend)
#### Appearance - Amikino
#### Aspects
#### Sigil - Amikino
### Histera - Drunkard's Pleasure
#### Appearance - Histera
#### Aspects

#### Sigil - Histera

### God’s Origin

***Icarus: Gods are created by the authors and placed on Shayi. They are born adults and knowing their function. Gods cannot have children. If they are killed or die of natural causes (they too are mortal), the authors will promptly replace them with a “copy” of the original.***

The gods have three ways of being put forth into the world: Birth from the sex between a god and another god;

The Author’s create them whenever they like, being given form and purpose by Mili and Kahuali, while magic and thought by Lesifi and Maghliphy;

Or be a champion given godhood by their god.