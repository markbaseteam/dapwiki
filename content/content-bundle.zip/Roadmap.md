---

kanban-plugin: basic

---

## Plans

- [ ] [[Authors (Look page on Progressed)]]
- [ ] [[Champions - Updates]]
- [ ] [[Cultures]]
- [ ] [[Fauna]]
- [ ] [[Fictional Materials]]
- [ ] [[Flora]]
- [ ] [[Geography]]
- [ ] [[Weapons and Mythical Objects]]
- [ ] [[Gods - Updates]]


## In Progress



## Cancelled

**Complete**


## Complete

**Complete**




%% kanban:settings
```
{"kanban-plugin":"basic","new-note-folder":"Planning Workspace/Shyi/Wiki - Publish"}
```
%%